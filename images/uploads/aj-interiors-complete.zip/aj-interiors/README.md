# AJ Interiors Website

## How to Edit Your Website
1. Open `admin/index.html` in your browser
2. Login: username `admin`, password `aj2025`
3. Edit content, upload photos, save changes
4. Go to Deploy tab → Download → Upload to Netlify

## How to Deploy on Netlify
1. Go to netlify.com → Sign up free
2. Click "Add new site" → "Deploy manually"  
3. Drag this entire folder onto Netlify
4. Done! Your site is live.
